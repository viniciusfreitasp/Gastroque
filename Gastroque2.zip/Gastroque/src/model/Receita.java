package model;

public class Receita {
	
	private String cdReceita;
	//private Integer idProduto;
	private Integer cdQtProduto;
	private String nmDescricao;
	
	public String getCdReceita() {
		return cdReceita;
	}
	public void setCdReceita(String cdReceita) {
		this.cdReceita = cdReceita;
	}
	
	public Integer getCdQtProduto() {
		return cdQtProduto;
	}
	public void setCdQtProduto(Integer cdQtProduto) {
		this.cdQtProduto = cdQtProduto;
	}
	public String getNmDescricao() {
		return nmDescricao;
	}
	public void setNmDescricao(String nmDescricao) {
		this.nmDescricao = nmDescricao;
	}
	

}
