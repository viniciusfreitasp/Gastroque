package model;

public class Categoria {
private int cdCategoria;
private String nmCategoria;

public int getCdCategoria() {
	return cdCategoria;
}
public void setCdCategoria(int cdCategoria) {
	this.cdCategoria = cdCategoria;
}
public String getNmCategoria() {
	return nmCategoria;
}
public void setNmCategoria(String nmCategoria) {
	this.nmCategoria = nmCategoria;
}

}
