package model;
import java.util.*;
import java.sql.*;
import java.util.ArrayList;

public class Produto {
    private int cdProduto;
    private String txNomeProduto;
    private String nmQtdMinima;
    private int nmUnidade;
    private int cdCategoria;
    private String tbProdutocol;
    
	public String getTbProdutocol() {
		return tbProdutocol;
	}
	public void setTbProdutocol(String tbProdutocol) {
		this.tbProdutocol = tbProdutocol;
	}
	public int getCdProduto() {
		return cdProduto;
	}
	public void setCdProduto(int cdProduto) {
		this.cdProduto = cdProduto;
	}
	public String getTxNomeProduto() {
		return txNomeProduto;
	}
	public void setTxNomeProduto(String txNomeProduto) {
		this.txNomeProduto = txNomeProduto;
	}
	public String getNmQtdMinima() {
		return nmQtdMinima;
	}
	public void setNmQtdMinima(String nmQtdMinima) {
		this.nmQtdMinima = nmQtdMinima;
	}
	public int getNmUnidade() {
		return nmUnidade;
	}
	public void setNmUnidade(int nmUnidade) {
		this.nmUnidade = nmUnidade;
	}
	public int getCdCategoria() {
		return cdCategoria;
	}
	public void setCdCategoria(int cdCategoria) {
		this.cdCategoria = cdCategoria;
	}
    
    
    
    
}
    

   
    