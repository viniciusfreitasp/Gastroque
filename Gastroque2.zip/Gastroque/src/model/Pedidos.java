/*package model;
import pessoa.Pessoa;
import model.Produto;
public class Pedidos {
	private int cdPedido;
	private int qtPedido;
	private String dtPedido;
	
	
	

}
*/