package pessoa;
import java.util.ArrayList;
import java.util.Scanner;

public class Principal {
	
	public static void main(String[] args) {
       
        Scanner ler  = new Scanner(System.in);
        ConnectBanco cb = new ConnectBanco("jdbc:mysql://URL", "LOGIN", "SENHA");
        int x=-1;
        String loginV;
        String senhaV;
        String login = "admin";
        String senha = "admin";
        while (x != 0) {
            System.out.println("Escolha uma opcao");
            System.out.println("1 - Cadastrar usuario");
            System.out.println("2 - Entrar");
            System.out.println("3 - Sair");
            x = Integer.parseInt(ler.nextLine());

            switch (x) {
                case 1: {
                    Pessoa pessoa = new Pessoa();

                    System.out.println("Digite um nome:");
                    pessoa.setNmUsuario(ler.nextLine());
                    
                    System.out.println("Digite o Telefone:");
                    pessoa.setTelefone(ler.nextLine());
                    System.out.println("Digite o E-mail:");
                    pessoa.setEmail(ler.nextLine());

                    cb.insere("INSERT INTO nome_do_banco_de_dados.nome_da_tabela VALUES(NULL , '" + pessoa.getNmUsuario() + "', '" + pessoa.getTelefone() + "', '" + pessoa.getEmail() + "');", "Usuario gravado corretamente...");
                    
                    System.out.print("Login: ");
                    login = ler.nextLine();
                    System.out.print("Senha: ");
                    senha = ler.nextLine();
                    break;
                }
                case 2: {
                   System.out.print("Login: ");
                   loginV = ler.nextLine();
                   System.out.print("Senha: ");
                   senhaV = ler.nextLine();
                   
                   if (loginV.equals(login) && senhaV.equals(senha)) {
                	   System.out.println("Aqui vai o programa!");
                	   System.out.println("Funcionou, v�i!");
                	   System.out.println("Aqui para o programa!");
                	   break;
                   }else {
                	   System.out.println("Login e/ou senha inv�lidos!");
                	   break;
                   }
                }
                
                case 3:{
                	x=0;
                }
                
            }

        }
    }

}

