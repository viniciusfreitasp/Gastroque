package model;

public class Categoria {

}
