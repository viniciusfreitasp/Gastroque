package model;

public class Produto {
    private String nmProduto;
    private int idProduto;
    private int qtda;
    private int estoque;
    private String descricao;

   
    public int getIdProduto() {
        return idProduto;
    }

   
    public void setIdProduto(int idProduto) {
        this.idProduto = idProduto;
    }

    public String getNmProduto() {
        return nmProduto;
    }

    
    public void setNmProduto(String nmProduto) {
        this.nmProduto = nmProduto;
    }

   
    public int getQtda() {
        return qtda;
    }

   
    public void setQtda(int qtda) {
        this.qtda = qtda;
    }

    public int getEstoque() {
        return estoque;
    }

   
    public void setEstoque(int estoque) {
        this.estoque = estoque;
    }

   
    public String getDescricao() {
        return descricao;
    }

   
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
}
