package model;

public class Receita {
	
	private String cdReceita;
	private Integer idProduto;
	private Integer cdQtProduto;
	public String getCdReceita() {
		return cdReceita;
	}
	public void setCdReceita(String cdReceita) {
		this.cdReceita = cdReceita;
	}
	public Integer getIdProduto() {
		return idProduto;
	}
	public void setIdProduto(Integer idProduto) {
		this.idProduto = idProduto;
	}
	public Integer getCdQtProduto() {
		return cdQtProduto;
	}
	public void setCdQtProduto(Integer cdQtProduto) {
		this.cdQtProduto = cdQtProduto;
	}
	

}
