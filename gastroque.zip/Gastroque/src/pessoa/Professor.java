package pessoa;

public class Professor extends Pessoa{
    public int cpf;
    private String setor;
   
@Override
public void setnmUsuario(String nmUsuario){
     if(!nmUsuario.equals("")){
         super.setId(nmUsuario);
     }
}
@Override
public String getid(){
    return super.getid();
}
public int getCpf() {
	return cpf;
}
public void setCpf(int cpf) {
	this.cpf = cpf;
}
public String getSetor() {
	return setor;
}
public void setSetor(String setor) {
	this.setor = setor;
}}