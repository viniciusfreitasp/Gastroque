package pessoa;

public class Pessoa{
    //aqui eu vou colocar somente alguns atributos e m�todos.
	private String id;
	private String nmUsuario;
	private String email;
	private String telefone;
	
	public String getId() {
		return id;
	}
	public void setId(String nmUsuario2) {
		this.id = nmUsuario2;
	}
	public String getNmUsuario() {
		return nmUsuario;
	}
	public void setNmUsuario(String nmUsuario) {
		this.nmUsuario = nmUsuario;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getTelefone() {
		return telefone;
	}
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	public void nmUsuario(String nmUsuario) {
		
		
	}
	public void setnmUsuario(String nmUsuario) {
		
		
	}
	public String getid() {
		// TODO Auto-generated method stub
		return null;
	}
}
   