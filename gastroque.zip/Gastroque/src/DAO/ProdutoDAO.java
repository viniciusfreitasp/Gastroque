package DAO;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import connection.Conexao;
import model.Produto;


public class ProdutoDAO {
    
    // metodo inserir da Dona alessandro
    public boolean inserir(Produto f){
        Connection con = new Conexao().getConnection();
        PreparedStatement stmt;
        
        try {
            String sql = "insert into produto(id_produto, quant_minima, estoque_atual, descricao)\n" +
                "values(?, ?, ?, ?); ";
            
            stmt = con.prepareStatement(sql);
            stmt.setString(1, f.getNmProduto());
            stmt.setInt(2, f.getQtda());
            stmt.setInt(3, f.getEstoque());
            stmt.setString(4, f.getDescricao());
           
            
            stmt.execute();
            con.close();
            
        } catch (SQLException ex) {
            Logger.getLogger(ProdutoDAO.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;
    }
    
    // metodo da Dona alessandro
    public List<Produto> selecionarTodos(){
        Connection con = new Conexao().getConnection();
        List<Produto> lista = new ArrayList<Produto>();
        
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery( "SELECT * FROM produto ORDER BY id_produto" );
            while ( rs.next() ) {
                Produto fo = new Produto();
                
               fo.setIdProduto( rs.getInt("id_produto") );
               fo.setNmProduto(rs.getString("nm_Produto") );
               fo.setQtda(rs.getInt("quant_minima") );
               fo.setEstoque(rs.getInt("estoque_atual") );
               fo.setDescricao(rs.getString("descricao") );

               lista.add(fo);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(ProdutoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return lista;
    }
    
    //atualizando da Dona alessandr
    public boolean atualizar(Produto f){
        Connection con = new Conexao().getConnection();
        PreparedStatement stmt;
        
        try {
            String sql = "update produto set nm_produto = ?, quant_minima = ?, estoque_atual = ?, descricao = ? where id_produto = ?";
            
            stmt = con.prepareStatement(sql);
            stmt.setString(1, f.getNmProduto());
            stmt.setInt(2, f.getQtda());
            stmt.setInt(3, f.getEstoque());
            stmt.setString(4, f.getDescricao());
            stmt.setInt(5, f.getIdProduto());
           
            
            stmt.execute();
            con.close();
            
        } catch (SQLException ex) {
            Logger.getLogger(ProdutoDAO.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;
    }
        
    //Deletando da Dona alessandr
    public boolean deletar(Produto f){
        Connection con = new Conexao().getConnection();
        PreparedStatement stmt;
        
        try {
            String sql = "delete from produto where id_produto = ?";
            
            stmt = con.prepareStatement(sql);
            stmt.setInt(1, f.getIdProduto());
           
            
            stmt.execute();
            con.close();
            
        } catch (SQLException ex) {
            Logger.getLogger(ProdutoDAO.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;
    }
        
    // buscandoda Dona alessandr
    public List<Produto> selecionarBusca(String busca){
        Connection con = new Conexao().getConnection();
        List<Produto> lista = new ArrayList<Produto>();
        Integer buscaInt;
        try{
            buscaInt = Integer.valueOf(busca);
        }catch(NumberFormatException ex){
            buscaInt = 0;
        }
        
        
        try {
            PreparedStatement stmt = con.prepareStatement("SELECT * FROM produto WHERE"
                +" id_produto = ?"
                +"OR nm_produto ILIKE ?"
                +"OR quant_minima = ?"
                +"OR estoque_atual = ?"
                +"OR descricao = ? ORDER BY id_produto"
            );
            stmt.setInt(1, buscaInt );
            stmt.setString(2, "%" + busca + "%");
            stmt.setInt(3, buscaInt );
            stmt.setInt(4, buscaInt);
            stmt.setString(5, "%" + busca + "%" );
            
            ResultSet rs = stmt.executeQuery();
            while ( rs.next() ) {
                Produto fo = new Produto();
                
               fo.setIdProduto( rs.getInt("id_produto") );
               fo.setNmProduto(rs.getString("nm_produto") );
               fo.setQtda(rs.getInt("quant_minima") );
               fo.setEstoque(rs.getInt("estoque_atual") );
               fo.setDescricao(rs.getString("descricao") );

               lista.add(fo);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(ProdutoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return lista;
    }
}
