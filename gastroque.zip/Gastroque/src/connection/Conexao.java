package connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {
    
    private static String url =  "jdbc:postgresql://localhost:5432/[NOMEBANCO]";
    private static String user = "[USUARIO]";
    private static String password = "[SENHA]";
   
    public Connection getConnection(){
        try{
            System.out.println("Conexao Concluida!!");
            return DriverManager.getConnection(url, user, password);
        
        } catch (SQLException ex) {
            System.out.println("Falha na conexao!!");
            throw new RuntimeException(ex);
        }
    }
}
